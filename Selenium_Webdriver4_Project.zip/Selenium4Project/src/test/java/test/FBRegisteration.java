package test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FBRegisteration
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.google.com");
		
		driver.navigate().to("https://www.facebook.com/signup");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.findElement(By.name("firstname")).sendKeys("Test Selenium");
		driver.findElement(By.name("lastname")).click();
		
		driver.findElement(By.name("reg_email__")).click();
		driver.findElement(By.name("reg_passwd__")).click();
		/*
		WebElement element=driver.findElement(By.id("day"));
		Select selectObject=new Select(element);
		selectObject.selectByValue("20");
		
		WebElement element2=driver.findElement(By.id("month"));
		Select selectObject2=new Select(element2);
		selectObject2.selectByValue("6");
		

		WebElement element3=driver.findElement(By.id("year"));
		Select selectObject3=new Select(element3);
		selectObject3.selectByValue("1998");
		*/
		
		Select sel=new Select(driver.findElement(By.id("day")));
		sel.selectByValue("20");
		
		Select sel2=new Select(driver.findElement(By.id("month")));
		sel2.selectByVisibleText("Sep");
		
		Select sel3=new Select(driver.findElement(By.id("year")));
		sel3.selectByIndex(6);
		
		
		
		//to get radio button
		driver.findElement(By.name("sex")).click();
		
		WebElement ele=driver.findElement(By.name("reg"));
		ele.submit();
		
		
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
		
	}
}
