package test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FBLogin 
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.google.com");
		
		driver.navigate().to("https://www.facebook.com/login/");
		
		driver.findElement(By.name("email")).sendKeys("SAYALI");
		driver.findElement(By.name("pass")).sendKeys("tesvdvfdhd4525545");
		driver.findElement(By.id("loginbutton")).click();
		
		Thread.sleep(2000);
		
		driver.close();
		driver.quit();
		
	}
}
