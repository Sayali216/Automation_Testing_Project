package test;

public class ProxyDemo 
{
	public static void main(String[] args)
	{
		
	}
}
