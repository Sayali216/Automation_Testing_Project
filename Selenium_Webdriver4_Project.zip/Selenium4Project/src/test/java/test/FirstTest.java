package test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstTest
{
	public static void main(String[] args)
	{
		//set property
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().timeouts().scriptTimeout(Duration.ofMinutes(2));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		
		
		//driver.get("https://www.google.com/");
		driver.get("https://www.facebook.com/");
		
		//driver.get("https://www.gmail.com/");
		
		
		driver.close();
		
		//driver.quit();
		
		
	}
}
