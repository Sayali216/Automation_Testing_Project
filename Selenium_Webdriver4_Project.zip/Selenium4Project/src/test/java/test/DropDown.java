package test;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDown 
{
	public static void main(String[] args) throws InterruptedException
	{
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		driver.get("https://trytestingthis.netlify.app/");
		//WebElement dropdown=driver .findElement(By.id("option"));
		//Select selectObject=new Select(dropdown);
		
		/*
		List<WebElement> allAvailableOptions=selectObject.getOptions();
		for(WebElement option:allAvailableOptions)
		{
			System.out.println(option.getText());
			if(option.getText().equalsIgnoreCase("option 2"));
			option.click();
			Thread.sleep(1000);
			
		}
		
		List<WebElement>allOptions= driver.findElements(By.id("option"));
		for(WebElement option:allOptions)
		{
			System.out.println(option.getText());
			
		}
		*/
		WebElement dropdown=driver .findElement(By.id("owc"));
		Select selectObject=new Select(dropdown);
		selectObject.selectByIndex(1);
		Thread.sleep(1000);
		selectObject.selectByValue("option 2");
		Thread.sleep(1000);
		selectObject.selectByValue("option 3");
		Thread.sleep(1000);
		selectObject.deselectByValue("option 3");
		
		/*
		 //to get Country drop down value
		driver.get("https://selenium08.blogspot.com/2019/11/dropdown.html");
		WebElement element=driver.findElement(By.name("country"));
		Select selectObject=new Select(element);
		
		selectObject.selectByVisibleText("Country...");
		Thread.sleep(2000);
		selectObject.selectByValue("AF");
		Thread.sleep(2000);
		selectObject.selectByValue("AL");
		Thread.sleep(2000);
		selectObject.selectByValue("DZ");
		Thread.sleep(2000);
		selectObject.selectByValue("AS");
		*/
		
		
		//to month drop down values in list
		/*
		driver.get("https://selenium08.blogspot.com/2019/11/dropdown.html");
		WebElement element=driver.findElement(By.name("Month"));
		Select selectObject=new Select(element);
		
		selectObject.selectByVisibleText("Month...");
		Thread.sleep(1000);
		selectObject.selectByValue("Jan");
		Thread.sleep(1000);
		selectObject.selectByValue("Feb");
		Thread.sleep(1000);
		selectObject.selectByValue("Ma");
		Thread.sleep(1000);
		selectObject.selectByValue("Ap");
		Thread.sleep(1000);
		selectObject.selectByValue("May");
		Thread.sleep(1000);
		selectObject.selectByValue("June");
		*/
		
		Thread.sleep(2000);
		driver.quit();
		System.out.println("Done");
	}
}
