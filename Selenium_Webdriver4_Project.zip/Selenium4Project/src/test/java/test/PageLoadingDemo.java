package test;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PageLoadingDemo 
{
	public static void main(String[] args) 
	{
		//ChromeOptions co=new ChromeOptions();
		//co.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		
		//ChromeOptions co=new ChromeOptions();
		//co.setPageLoadStrategy(PageLoadStrategy.EAGER);
		
		ChromeOptions co=new ChromeOptions();
		co.setPageLoadStrategy(PageLoadStrategy.NONE);
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver(co);
		
		driver.get("https://www.google.com");
		driver.quit();
		
		
	}

}
